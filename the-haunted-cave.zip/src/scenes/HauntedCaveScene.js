import Phaser from "phaser";
import Enemy from "../ui/Enemy";
export default class HauntedCaveScene extends Phaser.Scene {
  constructor() {
    super("Haunted-Cave-Scene");
  }
  init() {
    this.player = undefined;
    this.backsound = undefined;
    this.enemies = undefined;
    this.enemySpeed = 50;
  }
  preload() {
    this.load.image("bg1", "images/background1.png");
    this.load.image("bg2", "images/background2.png");
    this.load.image("bg3", "images/background3.png");
    this.load.image("bg4", "images/background4a.png");
    this.load.spritesheet("player", "images/player.png", {
      frameWidth: 32,
      frameHeight: 32,
    });
    this.load.image("ground", "images/ground.jpg");
    this.load.image("platform", "images/platform.png");
    this.load.spritesheet("playerjump", "images/3_Cat_Jump-Sheet.png", {
      frameWidth: 32,
      frameHeight: 32,
    });
    this.load.spritesheet("playerfall", "images/4_Cat_Fall-Sheet.png", {
      frameWidth: 32,
      frameHeight: 32,
    });
    this.load.spritesheet("playerrun", "images/2_Cat_Run-Sheet.png", {
      frameWidth: 32,
      frameHeight: 32,
    });
    this.load.audio("jump", "sfx/Mario-jump-sound.mp3");
    this.load.audio("fall", "sfx/wind-blowing-sfx.mp3");
    this.load.audio("bg-sfx", "sfx/bg-sfx.mp3");
    this.load.spritesheet("orc", "images/Orc-Idle.png", {
      frameWidth: 100,
      frameHeight: 32,
    });
    this.load.spritesheet("orc-walk", "images/Orc-Walk.png", {
      frameWidth: 100,
      frameHeight: 100,
    });
  }
  create() {
    const gameHalfWidth = this.scale.width / 2;
    const gameHalfHeight = this.scale.height / 2;
    this.add.image(gameHalfWidth, gameHalfHeight, "bg1").setScale(2);
    this.add.image(gameHalfWidth, gameHalfHeight, "bg2").setScale(2);
    this.add.image(gameHalfWidth, gameHalfHeight, "bg3").setScale(2);
    this.add.image(gameHalfWidth, gameHalfHeight, "bg4").setScale(2);
    // this.add.rectangle(
    //    gameHalfWidth,
    //  gameHalfHeight + 370,
    //this.scale.width,
    //200,
    //0xff0000
    //);
    this.ground = this.physics.add
      .staticImage(gameHalfWidth, gameHalfHeight + 400, "ground")
      .setScale(1.5)
      .refreshBody();
    this.player = this.physics.add
      .sprite(gameHalfWidth - 100, 200, "player")
      .setScale(2);
    this.physics.add.collider(this.player, this.ground);
    // this.platform = this.physics.add
    //  .sprite(gameHalfWidth, gameHalfHeight + 50, "platform")

    //   .refreshBody()
    //   // .setGravityY(-200)
    //   .setVelocityX(-20);
    this.platform = this.physics.add
      .image(gameHalfWidth, gameHalfHeight, "platform")
      .setScale(0.5);
    this.platform.setImmovable(true);
    this.platform.body.allowGravity = false;
    this.platform.setVelocityX(50);

    this.physics.add.collider(this.player, this.platform);
    this.player.anims.create({
      key: "player-idle",
      frames: this.anims.generateFrameNumbers("player", { start: 0, end: 7 }),
      frameRate: 10,
      repeat: -1,
    });
    this.player.anims.create({
      key: "player-jump",
      frames: this.anims.generateFrameNumbers("playerjump", {
        start: 0,
        end: 3,
      }),
      frameRate: 10,
      repeat: -1,
    });
    this.player.anims.create({
      key: "player-fall",
      frames: this.anims.generateFrameNumbers("playerfall", {
        start: 0,
        end: 3,
      }),
      frameRate: 10,
      repeat: -1,
    });
    this.player.anims.create({
      key: "player-run",
      frames: this.anims.generateFrameNumbers("playerrun", {
        start: 0,
        end: 9,
      }),
      frameRate: 10,
      repeat: -1,
    });
    //  this.player.anims.play("player-idle");
    this.cursors = this.input.keyboard.createCursorKeys();
    this.player.setCollideWorldBounds(true);

    this.backsound = this.sound.add("bg-sfx");
    var soundconfig = {
      loop: true,
    };
    this.backsound.play(soundconfig);
    this.enemies = this.physics.add.group({
      classType: Enemy,
      maxSize: 10,
      runChildUpdate: true,
    });

    this.time.addEvent({
      delay: Phaser.Math.Between(1000, 5000),
      callback: this.spawnEnemy,
      callbackScope: this,
      loop: true,
    });
    this.physics.add.collider(this.enemies, this.ground);
  }
  update() {
    if (this.platform.x >= 1500) {
      this.platform.setVelocityX(-50);
    } else if (this.platform.x <= 200) {
      this.platform.setVelocityX(50);
    }

    if (this.cursors.left.isDown) {
      this.player.setVelocityX(-120).setFlipX(true);
      if (this.player.body.touching.down) {
        this.player.anims.play("player-run", true);
      }
    } else if (this.cursors.right.isDown) {
      this.player.setVelocityX(120).setFlipX(false);
      if (this.player.body.touching.down) {
        this.player.anims.play("player-run", true);
      }
    } else {
      this.player.setVelocityX(0);
      if (this.player.body.touching.down) {
        this.player.anims.play("player-idle", true);
      }
    }

    if (this.cursors.up.isDown && this.player.body.touching.down) {
      this.player.setVelocityY(-400);
      //this.player.anims.play("player-jump", true);
      this.sound.play("jump");
    }

    this.physics.world.on("worldstep", () => {
      if (this.player.body.velocity.y < 0) {
        this.player.anims.play("player-jump", true);
      } else if (this.player.body.velocity.y > 0) {
        this.player.anims.play("player-fall", true);
        // this.sound.play("fall");
      }
    });
  }
  spawnEnemy() {
    const xSpawn = [100, 1500];
    const positionX = xSpawn[Phaser.Math.Between(0, 1)];

    const config = {
      speed: 30,
      spawnX: xSpawn,
    };
    //@ts-ignore
    const enemy = this.enemies.get(0, 0, "orc", config);

    if (enemy) {
      enemy.spawn(positionX);
    }
  }
}
