import Phaser from "phaser";
export default class Enemy extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, texture, config) {
    super(scene, x, y, texture);
    this.scene = scene;
    this.speed = config.speed;
    this.spawnX = config.spawnX;
  }
  spawn(positionX) {
    this.setPosition(positionX, 400);

    this.setActive(true);

    this.setVisible(true);
    this.setScale(3);
  }
  die() {
    this.destroy;
  }
  update() {
    if (this.spawnX == 1500) {
      this.setVelocityX(this.speed * -1);
    } else {
      this.setVelocityX(this.speed);
    }

    const gameWidth = this.scene.scale.width;
    // if (this.x > gameWidth + 5) {

    // }
  }
}
